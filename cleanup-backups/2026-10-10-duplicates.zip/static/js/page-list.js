// P1 + P2 — 卡片网格 + 放大弹层 + 翻转
const CATEGORIES = ["医", "工", "理", "文", "艺", "商", "教", "法"];

const state = { careers: [], category: null, q: "" };

const grid = document.getElementById("card-grid");
const catBar = document.getElementById("cat-filter");
const searchInput = document.getElementById("search-input");
const overlay = document.getElementById("modal-overlay");
const flipCard = document.getElementById("flip-card");
const faceFront = document.getElementById("face-front");
const faceBack = document.getElementById("face-back");
const flipHint = document.getElementById("flip-hint");

async function loadCareers() {
  const res = await fetch("/api/careers");
  state.careers = await res.json();
  renderCategories();
  renderGrid();
}

function renderCategories() {
  catBar.innerHTML = "";
  const all = document.createElement("button");
  all.className = "cat-btn" + (state.category === null ? " active" : "");
  all.textContent = "全部";
  all.onclick = () => { state.category = null; renderCategories(); renderGrid(); };
  catBar.appendChild(all);
  CATEGORIES.forEach((c) => {
    const btn = document.createElement("button");
    btn.className = "cat-btn" + (state.category === c ? " active" : "");
    btn.textContent = c;
    btn.onclick = () => { state.category = c; renderCategories(); renderGrid(); };
    catBar.appendChild(btn);
  });
}

function filtered() {
  return state.careers.filter((c) => {
    if (state.category && c.category !== state.category) return false;
    if (state.q) {
      const ql = state.q.toLowerCase();
      const hit =
        c.name.toLowerCase().includes(ql) ||
        c.tagline.toLowerCase().includes(ql) ||
        c.aliases.some((a) => a.toLowerCase().includes(ql));
      if (!hit) return false;
    }
    return true;
  });
}

function renderGrid() {
  const items = filtered();
  grid.innerHTML = "";
  if (!items.length) {
    grid.innerHTML = '<div class="empty-state">没有匹配的职业</div>';
    return;
  }
  items.forEach((c) => {
    const card = document.createElement("div");
    card.className = "career-card";
    card.dataset.id = c.id;
    card.innerHTML = `
      <span class="card-tag">${c.category}</span>
      <h3 class="card-title">${c.name}</h3>
      <p class="card-tagline">${c.tagline}</p>
    `;
    card.onclick = () => openModal(c.id);
    grid.appendChild(card);
  });
}

async function openModal(careerId) {
  const res = await fetch(`/api/careers/${careerId}`);
  if (!res.ok) return;
  const c = await res.json();
  flipCard.classList.remove("flipped");
  flipHint.textContent = "点卡片看日常工作";
  faceFront.innerHTML = `
    <span class="face-tag">${c.category}</span>
    <h2 class="face-title">${c.name}</h2>
    <p class="face-tagline">${c.tagline}</p>
  `;
  faceBack.innerHTML = `
    <div>
      <p class="face-section-title">典型任务</p>
      <ul class="face-list">${c.workday.tasks.map((t) => `<li>${t}</li>`).join("")}</ul>
    </div>
    <div>
      <p class="face-section-title">常见场景</p>
      <ul class="face-list">${c.workday.scenes.map((s) => `<li>${s}</li>`).join("")}</ul>
    </div>
    <div>
      <p class="face-section-title">工作节奏</p>
      <p class="face-text">${c.workday.rhythm}</p>
    </div>
    <p class="face-source">数据来源：${c.workday.source}<br>职业日常描述仅供参考，实际因单位/岗位而异</p>
  `;
  document.getElementById("btn-confirm").onclick = () => {
    window.location.href = `/career-subject?career_id=${c.id}`;
  };
  overlay.classList.remove("hidden");
}

document.getElementById("btn-flip").onclick = () => {
  flipCard.classList.toggle("flipped");
  flipHint.textContent = flipCard.classList.contains("flipped")
    ? "点卡片翻回正面"
    : "点卡片看日常工作";
};
flipCard.onclick = () => {
  flipCard.classList.toggle("flipped");
  flipHint.textContent = flipCard.classList.contains("flipped")
    ? "点卡片翻回正面"
    : "点卡片看日常工作";
};

document.getElementById("btn-close").onclick = () => overlay.classList.add("hidden");
overlay.onclick = (e) => { if (e.target === overlay) overlay.classList.add("hidden"); };
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") overlay.classList.add("hidden");
});

searchInput.addEventListener("input", (e) => {
  state.q = e.target.value;
  renderGrid();
});

(async function bootstrap() {
  await loadCareers();
  const openId = sessionStorage.getItem("open_career");
  if (openId) {
    sessionStorage.removeItem("open_career");
    openModal(openId);
  }
})();