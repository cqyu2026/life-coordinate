// P3 选科结果
const params = new URLSearchParams(window.location.search);
const careerId = params.get("career_id");

const titleEl = document.getElementById("career-name");
const listEl = document.getElementById("major-list");

async function load() {
  if (!careerId) {
    titleEl.textContent = "未指定职业";
    return;
  }
  const [careerResponse, subjectResponse] = await Promise.all([
    fetch(`/api/careers/${encodeURIComponent(careerId)}`),
    fetch(`/api/careers/${encodeURIComponent(careerId)}/subject`),
  ]);
  if (!careerResponse.ok || !subjectResponse.ok) {
    titleEl.textContent = "职业不存在";
    listEl.innerHTML = '<div class="empty-state">请返回首页重新选择职业。</div>';
    return;
  }
  const [c, s] = await Promise.all([careerResponse.json(), subjectResponse.json()]);
  titleEl.textContent = `${c.name} · 选科要求`;
  document.title = `${c.name} · life-coordinate`;
  listEl.innerHTML = "";
  if (!s.majors.length) {
    listEl.innerHTML = '<div class="empty-state">该职业暂无浙江招生数据</div>';
    return;
  }
  // 按科类分组：普通在上、艺考在下
  const 普通 = s.majors.filter((m) => m.category === "普通");
  const 艺考 = s.majors.filter((m) => m.category !== "普通");
  [...普通, ...艺考].forEach((m) => renderMajor(m));
}

function renderSubject(req) {
  if (!req) return '<span class="subject-chip">选科要求待按院校当年招生计划核对</span>';
  if (!req.must.length && !req.limit.length) {
    return '<span class="subject-chip any">不限选考</span>';
  }
  const parts = [];
  req.must.forEach((s) => parts.push(`<span class="subject-chip must">必选 ${s}</span>`));
  if (req.limit.length) {
    const cls = req.any ? "any" : "limit";
    const prefix = req.any ? "任选其一" : "限选";
    parts.push(`<span class="subject-chip ${cls}">${prefix} ${req.limit.join(" / ")}</span>`);
  }
  return parts.join("");
}

function renderMajor(m) {
  const card = document.createElement("div");
  card.className = "major-card";
  card.innerHTML = `
    <div class="major-head">
      <h3 class="major-name">${m.name}（${m.code}）</h3>
      <span class="major-cat">${m.category}</span>
    </div>
    <div class="subject-row">${renderSubject(m.subject_required)}</div>
    ${m.note ? `<div class="major-note">${m.note}</div>` : ""}
    <p class="major-source">数据来源：${m.source_url ? `<a href="${m.source_url}" target="_blank" rel="noopener noreferrer">${m.source}</a>` : m.source} · 发布年份 ${m.published}</p>
  `;
  listEl.appendChild(card);
}

document.getElementById("btn-back-home").onclick = () => (window.location.href = "/");
document.getElementById("btn-reverse").onclick = () => (window.location.href = "/subject");

load();
