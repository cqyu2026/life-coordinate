// P4 选科反查
const SUBJECTS = ["物理", "化学", "生物", "政治", "历史", "地理", "技术"];
const state = { selected: new Set() };

const optionsEl = document.getElementById("subject-options");
const previewEl = document.getElementById("preview-bar");
const listEl = document.getElementById("result-list");
let latestQuery = 0;

function renderOptions() {
  optionsEl.innerHTML = "";
  SUBJECTS.forEach((s) => {
    const btn = document.createElement("button");
    btn.className = "subject-toggle" + (state.selected.has(s) ? " active" : "");
    btn.textContent = s;
    btn.onclick = () => {
      if (state.selected.has(s)) state.selected.delete(s);
      else if (state.selected.size < 3) state.selected.add(s);
      else return;
      renderOptions();
      query();
    };
    optionsEl.appendChild(btn);
  });
}

async function query() {
  const queryId = ++latestQuery;
  const subjects = [...state.selected];
  if (!subjects.length) {
    previewEl.textContent = "请至少选 1 门";
    listEl.innerHTML = "";
    return;
  }
  let data;
  try {
    const res = await fetch(`/api/majors?subjects=${encodeURIComponent(subjects.join(","))}`);
    if (!res.ok) throw new Error("查询失败");
    data = await res.json();
  } catch {
    if (queryId === latestQuery) previewEl.textContent = "查询失败，请重试";
    return;
  }
  if (queryId !== latestQuery) return;
  previewEl.textContent = `参考匹配 ${data.length} 个专业（已选 ${subjects.length}/3；仅依据已录入院校的 2024 选科要求）`;
  listEl.innerHTML = "";
  if (!data.length) {
    listEl.innerHTML = '<div class="empty-state">当前选科组合暂未匹配到对应专业</div>';
    return;
  }
  data.forEach((r) => {
    const item = document.createElement("div");
    item.className = "result-item";
    const careersText = r.careers.length
      ? `对应职业：${r.careers.map((c) => c.name).join("、")}`
      : "暂无关联职业";
    item.innerHTML = `
      <div class="ri-left">
        <h3 class="ri-major">${r.major.name}</h3>
        <p class="ri-careers">${careersText}</p>
      </div>
      <span class="ri-cat">${r.major.category}</span>
    `;
    if (r.careers.length) {
      const jump = document.createElement("a");
      jump.className = "ri-jump";
      jump.textContent = "看职业日常 →";
      jump.href = `/#explore/${encodeURIComponent(r.careers[0].id)}`;
      item.appendChild(jump);
    }
    listEl.appendChild(item);
  });
}

renderOptions();
